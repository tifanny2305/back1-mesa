import { Pagea400f1d8715349c0a34cc39377dc62fcComponent } from './pages/page-a400f1d8-7153-49c0-a34c-c39377dc62fc/page-a400f1d8-7153-49c0-a34c-c39377dc62fc.component';

import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'página-1', pathMatch: 'full' },
  { path: 'página-1', component: Pagea400f1d8715349c0a34cc39377dc62fcComponent },


];
