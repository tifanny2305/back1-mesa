import { Component } from '@angular/core';

@Component({
  selector: 'app-page-df1f286f-7295-4c0f-b4dc-09c548dc3a4b',
  templateUrl: './page-df1f286f-7295-4c0f-b4dc-09c548dc3a4b.component.html',
  styleUrls: ['./page-df1f286f-7295-4c0f-b4dc-09c548dc3a4b.component.css']
})
export class Pagedf1f286f72954c0fb4dc09c548dc3a4bComponent {}