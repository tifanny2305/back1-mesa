import { Component } from '@angular/core';

@Component({
  selector: 'app-page-7703c255-c8b5-4ff0-9377-bd97f69384c5',
  templateUrl: './page-7703c255-c8b5-4ff0-9377-bd97f69384c5.component.html',
  styleUrls: ['./page-7703c255-c8b5-4ff0-9377-bd97f69384c5.component.css']
})
export class Page7703c255c8b54ff09377bd97f69384c5Component {}